/**
 * Site-specific localStorage utility
 * Prevents localStorage conflicts between different templates on same domain
 * Uses a unique site ID generated on first load
 */

let sitePrefix: string | null = null;
const SITE_ID_KEY = "__site_id__"; // Raw key, no prefix

/**
 * Generate a unique site ID (UUID v4)
 */
const generateSiteId = (): string => {
  return (
    "site_" +
    "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g, function (c) {
      const r = (Math.random() * 16) | 0;
      const v = c === "x" ? r : (r & 0x3) | 0x8;
      return v.toString(16);
    })
  );
};

/**
 * Get or create site-specific localStorage prefix
 * Each site gets a unique ID on first load
 */
const getSitePrefix = (): string => {
  if (sitePrefix) return sitePrefix;

  try {
    // Check if site already has a unique ID
    let siteId = localStorage.getItem(SITE_ID_KEY);

    if (!siteId) {
      // First load - generate and save unique site ID
      siteId = generateSiteId();
      localStorage.setItem(SITE_ID_KEY, siteId);
      console.log("🆔 Generated new site ID:", siteId);
    }

    sitePrefix = siteId;
    return sitePrefix;
  } catch (error) {
    console.error("Failed to get/create site ID:", error);
    // Fallback to timestamp-based ID
    sitePrefix = "site_" + Date.now();
    return sitePrefix;
  }
};

/**
 * Get site-specific localStorage key
 */
export const getStorageKey = (key: string): string => {
  const prefix = getSitePrefix();
  return `${prefix}_${key}`;
};

/**
 * Get item from localStorage with site-specific key
 */
export const getItem = (key: string): string | null => {
  try {
    return localStorage.getItem(getStorageKey(key));
  } catch (error) {
    console.error(`Error reading from localStorage (${key}):`, error);
    return null;
  }
};

/**
 * Set item to localStorage with site-specific key
 */
export const setItem = (key: string, value: string): void => {
  try {
    localStorage.setItem(getStorageKey(key), value);
  } catch (error) {
    console.error(`Error writing to localStorage (${key}):`, error);
  }
};

/**
 * Remove item from localStorage with site-specific key
 */
export const removeItem = (key: string): void => {
  try {
    localStorage.removeItem(getStorageKey(key));
  } catch (error) {
    console.error(`Error removing from localStorage (${key}):`, error);
  }
};

/**
 * Clear all site-specific items from localStorage
 */
export const clearSiteStorage = (): void => {
  try {
    const prefix = getSitePrefix();
    const keys = Object.keys(localStorage);
    keys.forEach((key) => {
      if (key.startsWith(`${prefix}_`)) {
        localStorage.removeItem(key);
      }
    });
  } catch (error) {
    console.error("Error clearing site storage:", error);
  }
};
