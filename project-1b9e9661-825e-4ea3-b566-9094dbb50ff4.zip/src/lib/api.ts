import axios, { type AxiosInstance, type AxiosResponse } from "axios";
import constants from "@/constants/constants.json";

// API service class
class ApiService {
  private axiosInstance: AxiosInstance;
  private settings: any = null;

  constructor() {
    // Default configuration - will be updated when settings load
    this.axiosInstance = axios.create({
      baseURL: "https://backend.promake.ai/api",
      timeout: 30000,
      headers: {
        "Content-Type": "application/json",
      },
    });

    // Request interceptor to add site slug
    this.axiosInstance.interceptors.request.use(
      (config) => {
        if (this.settings?.site?.slug) {
          config.headers["X-Site-Slug"] = this.settings.site.slug;
        }
        return config;
      },
      (error) => {
        return Promise.reject(error);
      },
    );

    // Response interceptor for error handling
    this.axiosInstance.interceptors.response.use(
      (response: AxiosResponse) => response,
      (error) => {
        console.error("API Error:", {
          status: error.response?.status,
          statusText: error.response?.statusText,
          data: error.response?.data,
          url: error.config?.url,
        });
        return Promise.reject(error);
      },
    );
  }

  // Update settings for API configuration
  updateSettings(settings: any) {
    this.settings = settings;
    if (settings?.api?.baseUrl) {
      this.axiosInstance.defaults.baseURL = settings.api.baseUrl;
    }
    if (settings?.api?.timeout) {
      this.axiosInstance.defaults.timeout = settings.api.timeout;
    }
  }

  // Get endpoint from settings
  private getEndpoint(key: string): string {
    return this.settings?.api?.endpoints?.[key] || `/${key}`;
  }

  // Order API methods
  async createOrder(orderData: {
    user_id: string;
    total_price: number;
    status: string;
    payment_method: string;
    shipping_address: any;
    notes?: string | null;
    items: Array<{
      product_id: number;
      quantity: number;
      price: number;
    }>;
  }): Promise<{ orderId: number; success: boolean }> {
    try {
      const response = await this.axiosInstance.post(
        this.getEndpoint("orders"),
        {
          site_slug: this.settings?.site?.slug || "promake",
          order: {
            user_id: orderData.user_id,
            total_price: orderData.total_price,
            status: orderData.status,
            payment_method: orderData.payment_method,
            shipping_address: orderData.shipping_address,
            notes: orderData.notes,
          },
          items: orderData.items,
        },
      );

      return {
        orderId: response.data.order_id,
        success: true,
      };
    } catch (error: any) {
      console.error("Order creation failed:", error);
      throw new Error(error.response?.data?.message || "Order creation failed");
    }
  }


  // Generic form submission with file upload to mail service
  async submitFormWithFile(
    formData: Record<string, any>,
    formConfig: {
      email_subject1: string;
      email_subject2: string;
      fields: Array<{ name: string; required: boolean }>;
    },
    currentLanguage: string = "en",
  ): Promise<{ success: boolean; message: string }> {
    try {
      const customerEmail = formData["email"];
      if (!customerEmail) {
        throw new Error("Email field is required in form data");
      }

      const tenantEmail = constants.email || import.meta.env.VITE_TENANT_MAIL;
          if (!tenantEmail) {
        throw new Error("VITE_TENANT_MAIL environment variable is not set");
      }

      const mailServiceUrl =
        import.meta.env.VITE_MAIL_SERVICE_URL ||
        "https://mail.promake.ai/api/v1/send-mail";

      // Check if there are attachments to determine request type
      const hasAttachments = formData.attachments &&
        Array.isArray(formData.attachments) &&
        formData.attachments.length > 0;

      if (hasAttachments) {
        // Use FormData for file uploads
        const formDataObj = new FormData();

        formDataObj.append('target_email1', customerEmail);
        formDataObj.append('target_email2', tenantEmail);
        formDataObj.append('email_subject1', formConfig.email_subject1);
        formDataObj.append('email_subject2', formConfig.email_subject2);

        // Add form fields
        formConfig.fields.forEach((field) => {
          if (field.name !== 'attachments') {
            formDataObj.append(`data[${field.name}][required]`, field.required.toString());
            formDataObj.append(`data[${field.name}][value]`, formData[field.name] || '');
          }
        });

        // Add attachments
        formData.attachments.forEach((file: File) => {
          formDataObj.append('attachments[]', file);
        });

        const response = await axios.post(mailServiceUrl, formDataObj, {
          headers: {
            'Accept-Language': currentLanguage,
            'Content-Type': 'multipart/form-data',
          },
        });

        return {
          success: true,
          message: response.data.message || "Form submitted successfully",
        };
      } else {
        // Use JSON for simple forms (backward compatible)
        const data: Record<string, { required: boolean; value: any }> = {};

       
       formConfig.fields.forEach((field) => {
        if (field.name !== 'attachments') { 
          data[field.name] = {
            required: field.required,
            value: formData[field.name] || null,
          };
        }
      });

        const response = await axios.post(
          mailServiceUrl,
          {
            target_email1: customerEmail,
            target_email2: tenantEmail,
            email_subject1: formConfig.email_subject1,
            email_subject2: formConfig.email_subject2,
            data: data,
          },
          {
            headers: {
              "Accept-Language": currentLanguage,
              "Content-Type": "application/json",
            },
          },
        );

        return {
          success: true,
          message: response.data.message || "Form submitted successfully",
        };
      }
    } catch (error: any) {
      console.error("Form submission failed:", error);
      throw new Error(error.response?.data?.message || "Failed to submit form");
    }
  }


  // DEPRECATED: Use submitFormWithFile instead
  // Keeping for backward compatibility
  // Generic form submission to mail service
  async submitForm(
    formData: Record<string, any>,
    formConfig: {
      email_subject1: string;
      email_subject2: string;
      fields: Array<{ name: string; required: boolean }>;
    },
    currentLanguage: string = "en",
  ): Promise<{ success: boolean; message: string }> {
    try {
      // Extract customer email from form data
      const customerEmail = formData["email"];
      if (!customerEmail) {
        throw new Error("Email field is required in form data");
      }

      // Get site owner email from ENV
      const tenantEmail = constants.email || import.meta.env.VITE_TENANT_MAIL;
      if (!tenantEmail) {
        throw new Error("VITE_TENANT_MAIL environment variable is not set");
      }

      // Convert formData to backend expected format with required info from config
      const data: Record<string, { required: boolean; value: any }> = {};

      formConfig.fields.forEach((field) => {
        data[field.name] = {
          required: field.required,
          value: formData[field.name] || null,
        };
      });

      // Get mail service URL from ENV
      const mailServiceUrl =
        import.meta.env.VITE_MAIL_SERVICE_URL ||
        "https://mail.promake.ai/api/v1/send-mail";

      // Make request to mail service
      const response = await axios.post(
        mailServiceUrl,
        {
          target_email1: customerEmail,
          target_email2: tenantEmail,
          email_subject1: formConfig.email_subject1,
          email_subject2: formConfig.email_subject2,
          data: data,
        },
        {
          headers: {
            "Accept-Language": currentLanguage,
            "Content-Type": "application/json",
          },
        },
      );

      return {
        success: true,
        message: response.data.message || "Form submitted successfully",
      };
    } catch (error: any) {
      console.error("Form submission failed:", error);
      throw new Error(error.response?.data?.message || "Failed to submit form");
    }
  }

  // DEPRECATED: Use submitForm instead
  // Keeping for backward compatibility
  async submitContactForm(contactData: {
    name: string;
    email: string;
    subject?: string;
    message: string;
  }): Promise<{ success: boolean; message: string }> {
    console.warn("submitContactForm is deprecated. Use submitForm instead.");
    return this.submitForm(
      contactData,
      {
        email_subject1: "Contact Form Submission",
        email_subject2: "New Contact Form",
        fields: [
          { name: "name", required: true },
          { name: "email", required: true },
          { name: "subject", required: false },
          { name: "message", required: true },
        ],
      },
      "en",
    );
  }

  // Get order by ID (for order confirmation page)
  async getOrderById(orderId: number): Promise<any | null> {
    try {
      const response = await this.axiosInstance.get(
        `${this.getEndpoint("orders")}/${orderId}?site_slug=${this.settings?.site?.slug
        }`,
      );
      return response.data.order || null;
    } catch (error: any) {
      console.error("Failed to fetch order:", error);
      return null;
    }
  }
}

// Create singleton instance
const apiService = new ApiService();

// Hook to use API service with settings
export const useApiService = () => {
  // Reconstruct settings object for ApiService.updateSettings
  const settings = {
    site: {
      slug: constants.site.slug,
    },
    api: {
      baseUrl: constants.api.baseUrl,
      timeout: constants.api.timeout,
      endpoints: constants.api.endpoints,
    },
  };

  // Update API service settings when they change
  if (settings && apiService) {
    apiService.updateSettings(settings);
  }

  return apiService;
};

// Export the service for direct use
export default apiService;
