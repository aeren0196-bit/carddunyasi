// Environment değişkenlerini window'a export et
declare global {
  interface Window {
    ENV: {
      [key: string]: any;
    };
  }
}

window.ENV = {
  ...Object.keys(import.meta.env)
    .filter((key) => key.startsWith('VITE_'))
    .reduce(
      (acc, key) => ({
        ...acc,
        [key]: import.meta.env[key],
      }),
      {},
    ),
}; 