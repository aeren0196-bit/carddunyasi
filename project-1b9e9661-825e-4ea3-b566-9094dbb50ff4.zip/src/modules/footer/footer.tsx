import { useMemo } from "react";
import { Link } from "react-router";
import { Mail, Phone, MapPin, Facebook, Twitter, Instagram, Linkedin } from "lucide-react";
import { Logo } from "@/components/Logo";
import constants from "@/constants/constants.json";
import { useTranslation } from "react-i18next";

const socialIcons: Record<string, React.ElementType> = {
  facebook: Facebook,
  twitter: Twitter,
  instagram: Instagram,
  linkedin: Linkedin,
};

export function Footer() {
  const { t } = useTranslation("footer");

  const socialLinks = useMemo(() => {
    const socialMedia = constants.socialMedia as Record<string, string> | undefined;
    if (!socialMedia) return [];
    return Object.entries(socialMedia)
      .filter(([platform, url]) => url && socialIcons[platform])
      .map(([platform, url]) => ({ platform, url, Icon: socialIcons[platform] }));
  }, []);

  const currentYear = new Date().getFullYear();

  return (
    <footer className="border-t bg-muted/20">
      <div className="w-full max-w-[var(--container-max-width)] mx-auto px-4 py-12 lg:py-16">
        <div className="grid grid-cols-1 gap-10 md:grid-cols-2 lg:grid-cols-4">
          {/* Brand */}
          <div className="space-y-4">
            <Logo size="md" />
            <p className="text-sm text-muted-foreground leading-relaxed">
              {t("description", "Quality products and exceptional service for our valued customers.")}
            </p>
            {socialLinks.length > 0 && (
              <div className="flex gap-1">
                {socialLinks.map(({ platform, url, Icon }) => (
                  <a
                    key={platform}
                    href={url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="h-9 w-9 flex items-center justify-center rounded-lg text-muted-foreground hover:text-foreground hover:bg-muted transition-colors"
                  >
                    <Icon className="h-4 w-4" />
                  </a>
                ))}
              </div>
            )}
          </div>

          {/* Quick Links */}
          <div className="space-y-4">
            <h4 className="font-semibold">{t("quickLinks", "Quick Links")}</h4>
            <ul className="space-y-2.5">
              <li>
                <Link to="/about" className="text-sm text-muted-foreground hover:text-foreground transition-colors">
                  {t("about", "About")}
                </Link>
              </li>
              <li>
                <Link to="/contact" className="text-sm text-muted-foreground hover:text-foreground transition-colors">
                  {t("contact", "Contact")}
                </Link>
              </li>
            </ul>
          </div>

          {/* Legal */}
          <div className="space-y-4">
            <h4 className="font-semibold">{t("legal", "Legal")}</h4>
            <ul className="space-y-2.5">
              <li>
                <Link to="/privacy" className="text-sm text-muted-foreground hover:text-foreground transition-colors">
                  {t("privacy", "Privacy Policy")}
                </Link>
              </li>
              <li>
                <Link to="/terms" className="text-sm text-muted-foreground hover:text-foreground transition-colors">
                  {t("terms", "Terms of Service")}
                </Link>
              </li>
              <li>
                <Link to="/cookies" className="text-sm text-muted-foreground hover:text-foreground transition-colors">
                  {t("cookies", "Cookie Policy")}
                </Link>
              </li>
            </ul>
          </div>

          {/* Contact */}
          <div className="space-y-4">
            <h4 className="font-semibold">{t("contactTitle", "Contact")}</h4>
            <ul className="space-y-3">
              <li className="flex items-center gap-3 text-sm text-muted-foreground">
                <Phone className="h-4 w-4 shrink-0" />
                <span>{constants.phone}</span>
              </li>
              <li className="flex items-center gap-3 text-sm text-muted-foreground">
                <Mail className="h-4 w-4 shrink-0" />
                <span>{constants.email}</span>
              </li>
              <li className="flex items-start gap-3 text-sm text-muted-foreground">
                <MapPin className="h-4 w-4 shrink-0 mt-0.5" />
                <span>
                  {constants.address.city}, {constants.address.state}
                </span>
              </li>
            </ul>
          </div>
        </div>

        {/* Bottom */}
        <div className="mt-12 pt-6 border-t">
          <p className="text-sm text-muted-foreground text-center">
            © {currentYear} {constants.site.name}. {t("allRightsReserved", "All rights reserved.")}
          </p>
        </div>
      </div>
    </footer>
  );
}
