export * from './faq-simple';
