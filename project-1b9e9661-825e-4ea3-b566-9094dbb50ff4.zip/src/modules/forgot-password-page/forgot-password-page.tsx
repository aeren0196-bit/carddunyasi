import { useState } from "react";
import { Link } from "react-router";
import { toast } from "sonner";
import { Layout } from "@/components/Layout";
import { usePageTitle } from "@/hooks/use-page-title";
import { useTranslation } from "react-i18next";
import { useAuth } from "@/modules/auth-core";
import { getErrorMessage } from "@/modules/api";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
  CardDescription,
} from "@/components/ui/card";
import { KeyRound, ArrowLeft,  CheckCircle2 } from "lucide-react";
import { FormField } from "@/components/FormField";
import { PasswordInput } from "@/components/PasswordInput";

type Step = "request" | "reset" | "success";

export function ForgotPasswordPage() {
  const { t } = useTranslation("forgot-password-page");
  usePageTitle({ title: t("title", "Forgot Password") });

  const { forgotPassword, resetPassword } = useAuth();

  const [step, setStep] = useState<Step>("request");
  const [email, setEmail] = useState("");
  const [code, setCode] = useState("");
  const [newPassword, setNewPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleRequestCode = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    setError(null);

    try {
      await forgotPassword(email);
      toast.success(t("codeSentTitle", "Code Sent!"), {
        description: t(
          "codeSentDesc",
          "A password reset code has been sent to your email.",
        ),
      });
      setStep("reset");
    } catch (err) {
      const errorMessage = getErrorMessage(
        err,
        t("errorGeneric", "Failed to send reset code. Please try again."),
      );
      setError(errorMessage);
      toast.error(t("errorTitle", "Error"), {
        description: errorMessage,
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleResetPassword = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    // Validate passwords match
    if (newPassword !== confirmPassword) {
      setError(t("passwordMismatch", "Passwords do not match"));
      return;
    }

    setIsSubmitting(true);

    try {
      await resetPassword(email, code, newPassword);
      toast.success(t("resetSuccessTitle", "Password Reset!"), {
        description: t(
          "resetSuccessDesc",
          "Your password has been successfully reset.",
        ),
      });
      setStep("success");
    } catch (err) {
      const errorMessage = getErrorMessage(
        err,
        t("errorResetGeneric", "Failed to reset password. Please try again."),
      );
      setError(errorMessage);
      toast.error(t("errorTitle", "Error"), {
        description: errorMessage,
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  // Success step
  if (step === "success") {
    return (
      <Layout>
        <div className="min-h-screen bg-muted/30 py-12">
          <div className="w-full max-w-[var(--container-max-width)] mx-auto px-4">
            <div className="max-w-md mx-auto">
              <Card>
                <CardContent className="pt-8 pb-8 text-center">
                  <CheckCircle2 className="w-16 h-16 text-green-500 mx-auto mb-4" />
                  <h1 className="text-2xl font-bold mb-2">
                    {t("successTitle", "Password Reset Successfully!")}
                  </h1>
                  <p className="text-muted-foreground mb-6">
                    {t(
                      "successDescription",
                      "Your password has been changed. You can now login with your new password.",
                    )}
                  </p>
                  <Button asChild className="w-full">
                    <Link to="/login">{t("goToLogin", "Go to Login")}</Link>
                  </Button>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </Layout>
    );
  }

  return (
    <Layout>
      <div className="min-h-screen bg-muted/30 py-12">
        <div className="w-full max-w-[var(--container-max-width)] mx-auto px-4">
          {/* Hero Section */}
          <div className="text-center mb-12">
            <h1 className="text-4xl font-bold text-foreground mb-4">
              {t("title", "Forgot Password")}
            </h1>
            <div className="w-16 h-1 bg-primary mx-auto mb-6"></div>
            <p className="text-lg text-muted-foreground max-w-xl mx-auto">
              {step === "request"
                ? t(
                  "descriptionRequest",
                  "Enter your email and we'll send you a code to reset your password.",
                )
                : t(
                  "descriptionReset",
                  "Enter the code sent to your email and your new password.",
                )}
            </p>
          </div>

          <div className="max-w-md mx-auto">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <KeyRound className="w-5 h-5 text-primary" />
                  {step === "request"
                    ? t("cardTitleRequest", "Request Reset Code")
                    : t("cardTitleReset", "Reset Password")}
                </CardTitle>
                <CardDescription>
                  {step === "request"
                    ? t("cardDescRequest", "Step 1 of 2: Request a reset code")
                    : t(
                      "cardDescReset",
                      "Step 2 of 2: Enter code and new password",
                    )}
                </CardDescription>
              </CardHeader>
              <CardContent>
                {step === "request" ? (
                  // Step 1: Request Code
                  <form onSubmit={handleRequestCode} className="space-y-6">
                    <FormField label={t("email", "Email")} htmlFor="email" required>
                      <Input
                        id="email"
                        type="email"
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                        placeholder={t("emailPlaceholder", "Enter your email")}
                        required
                        className="mt-1"
                        autoComplete="email"
                      />
                    </FormField>

                    {error && (
                      <div className="p-4 bg-red-50 border border-red-200 rounded-lg">
                        <p className="text-red-800 text-sm font-medium">
                          {error}
                        </p>
                      </div>
                    )}

                    <Button
                      type="submit"
                      size="lg"
                      className="w-full"
                      disabled={isSubmitting}
                    >
                      {isSubmitting ? (
                        <>
                          <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin mr-2" />
                          {t("sending", "Sending...")}
                        </>
                      ) : (
                        t("sendCode", "Send Reset Code")
                      )}
                    </Button>

                    <div className="text-center">
                      <Link
                        to="/login"
                        className="text-sm text-muted-foreground hover:text-primary inline-flex items-center gap-1"
                      >
                        <ArrowLeft className="w-4 h-4" />
                        {t("backToLogin", "Back to Login")}
                      </Link>
                    </div>
                  </form>
                ) : (
                  // Step 2: Reset Password
                  <form onSubmit={handleResetPassword} className="space-y-6">
                    <div className="p-3 bg-muted rounded-lg text-sm">
                      <span className="text-muted-foreground">
                        {t("codeFor", "Reset code for:")}{" "}
                      </span>
                      <span className="font-medium">{email}</span>
                    </div>
                    <FormField label={t("code", "Reset Code")} htmlFor="code" required>
                      <Input
                        id="code"
                        type="text"
                        value={code}
                        onChange={(e) => setCode(e.target.value)}
                        placeholder={t("codePlaceholder", "Enter 6-digit code")}
                        required
                        className="mt-1"
                        maxLength={6}
                      />
                    </FormField>
                    <FormField label={t("newPassword", "New Password")} htmlFor="new-password" required>
                      <PasswordInput
                        id="new-password"
                        name="new-password"
                        value={newPassword}
                        onChange={(e) => setNewPassword(e.target.value)}
                        placeholder={t("newPasswordPlaceholder", "Enter new password")}
                        required
                        className="mt-1"
                        autoComplete="new-password"
                      />
                    </FormField>
                    <div>
                      <p className="text-xs text-muted-foreground mt-1">
                        {t(
                          "passwordRequirements",
                          "At least 8 characters, 1 letter and 1 number",
                        )}
                      </p>
                    </div>

                    <FormField label={t("confirmPassword", "Confirm Password")} htmlFor="confirm-password" required>
                      <PasswordInput
                        id="confirm-password"
                        value={confirmPassword}
                        name="confirm-password"
                        onChange={(e) => setConfirmPassword(e.target.value)}
                        placeholder={t("confirmPasswordPlaceholder", "Confirm new password")}
                        required
                        className="mt-1"
                        autoComplete="new-password"
                      />
                      </FormField>

                    {error && (
                      <div className="p-4 bg-red-50 border border-red-200 rounded-lg">
                        <p className="text-red-800 text-sm font-medium">
                          {error}
                        </p>
                      </div>
                    )}

                    <Button
                      type="submit"
                      size="lg"
                      className="w-full"
                      disabled={isSubmitting}
                    >
                      {isSubmitting ? (
                        <>
                          <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin mr-2" />
                          {t("resetting", "Resetting...")}
                        </>
                      ) : (
                        t("resetPassword", "Reset Password")
                      )}
                    </Button>

                    <div className="flex justify-between">
                      <button
                        type="button"
                        onClick={() => {
                          setStep("request");
                          setCode("");
                          setNewPassword("");
                          setConfirmPassword("");
                          setError(null);
                        }}
                        className="text-sm text-muted-foreground hover:text-primary"
                      >
                        {t("changeEmail", "Change email")}
                      </button>
                      <button
                        type="button"
                        onClick={() =>
                          handleRequestCode({
                            preventDefault: () => { },
                          } as React.FormEvent)
                        }
                        className="text-sm text-primary hover:underline"
                        disabled={isSubmitting}
                      >
                        {t("resendCode", "Resend code")}
                      </button>
                    </div>
                  </form>
                )}
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </Layout>
  );
}

export default ForgotPasswordPage;
