export * from './forgot-password-page';
export { default } from './forgot-password-page';
