import { useState, useEffect } from "react";
import { Link, useNavigate } from "react-router";
import { toast } from "sonner";
import { Layout } from "@/components/Layout";
import { usePageTitle } from "@/hooks/use-page-title";
import { useTranslation } from "react-i18next";
import { useAuth } from "@/modules/auth-core";
import { getErrorMessage } from "@/modules/api";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { UserPlus } from "lucide-react";
import { PasswordInput } from "@/components/PasswordInput";
import { FormField } from "@/components/FormField";

export function RegisterPage() {
  const { t } = useTranslation("register-page");
  usePageTitle({ title: t("title", "Create Account") });

  const navigate = useNavigate();
  const { register, isAuthenticated } = useAuth();

  const [formData, setFormData] = useState({
    username: "",
    email: "",
    password: "",
    confirmPassword: "",
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // Redirect if already authenticated
  useEffect(() => {
    if (isAuthenticated) {
      navigate("/", { replace: true });
    }
  }, [isAuthenticated, navigate]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    setError(null);

    // Validate passwords match
    if (formData.password !== formData.confirmPassword) {
      setError(t("passwordMismatch", "Passwords do not match"));
      toast.error(t("toastErrorTitle", "Registration failed"), {
        description: t("passwordMismatch", "Passwords do not match"),
      });
      setIsSubmitting(false);
      return;
    }

    try {
      await register(formData.username, formData.email, formData.password);
      toast.success(t("toastSuccessTitle", "Account created!"), {
        description: t("toastSuccessDesc", "You can now sign in."),
      });
      navigate("/login");
    } catch (err) {
      const errorMessage = getErrorMessage(
        err,
        t("errorGeneric", "Registration failed. Please try again.")
      );
      setError(errorMessage);
      toast.error(t("toastErrorTitle", "Registration failed"), {
        description: errorMessage,
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setFormData((prev) => ({
      ...prev,
      [e.target.name]: e.target.value,
    }));
  };

  return (
    <Layout>
      <div className="min-h-screen bg-muted/30 py-12">
        <div className="w-full max-w-[var(--container-max-width)] mx-auto px-4">
          {/* Hero Section */}
          <div className="text-center mb-12">
            <h1 className="text-4xl font-bold text-foreground mb-4">
              {t("title", "Create Account")}
            </h1>
            <div className="w-16 h-1 bg-primary mx-auto mb-6"></div>
            <p className="text-lg text-muted-foreground max-w-xl mx-auto">
              {t("description", "Create an account to get started")}
            </p>
          </div>

          <div className="max-w-md mx-auto">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <UserPlus className="w-5 h-5 text-primary" />
                  {t("cardTitle", "Sign Up")}
                </CardTitle>
              </CardHeader>
              <CardContent>
                <form onSubmit={handleSubmit} className="space-y-6">
                  <FormField
                    label={t("username", "Username")}
                    htmlFor="username"
                    required
                  >
                    <Input
                      id="username"
                      name="username"
                      type="text"
                      value={formData.username}
                      onChange={handleChange}
                      placeholder={t(
                        "usernamePlaceholder",
                        "Enter your username"
                      )}
                      required
                      className="mt-1"
                      autoComplete="username"
                    />
                  </FormField>
                  <FormField
                    label={t("email", "Email")}
                    htmlFor="email"
                    required
                  >
                    <Input
                      id="email"
                      name="email"
                      type="email"
                      value={formData.email}
                      onChange={handleChange}
                      placeholder={t("emailPlaceholder", "Enter your email")}
                      required
                      className="mt-1"
                      autoComplete="email"
                    />
                  </FormField>
                  <FormField
                    label={t("password", "Password")}
                    htmlFor="password"
                    required
                  >
                    <PasswordInput
                      id="password"
                      name="password"
                      value={formData.password}
                      onChange={handleChange}
                      placeholder={t("passwordPlaceholder", "Enter password")}
                      required
                      className="mt-1 pr-10"
                      autoComplete="new-password"
                    />
                  </FormField>

                  <FormField
                    label={t("confirmPassword", "Confirm Password")}
                    htmlFor="confirmPassword"
                    required
                  >
                    <PasswordInput
                      id="confirmPassword"
                      name="confirmPassword"
                      value={formData.confirmPassword}
                      onChange={handleChange}
                      placeholder={t("passwordPlaceholder", "Enter password")}
                      required
                      className="mt-1 pr-10"
                      autoComplete="new-password"
                    />
                  </FormField>

                  {error && (
                    <div className="p-4 bg-red-50 border border-red-200 rounded-lg">
                      <p className="text-red-800 text-sm font-medium">
                        {error}
                      </p>
                    </div>
                  )}

                  <Button
                    type="submit"
                    className="w-full"
                    disabled={isSubmitting}
                  >
                    {isSubmitting
                      ? t("submitting", "Creating account...")
                      : t("submit", "Create Account")}
                  </Button>

                  <div className="text-center text-sm text-muted-foreground">
                    {t("hasAccount", "Already have an account?")}{" "}
                    <Link
                      to="/login"
                      className="text-primary hover:underline font-medium"
                    >
                      {t("loginLink", "Sign in")}
                    </Link>
                  </div>
                </form>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </Layout>
  );
}

export default RegisterPage;
