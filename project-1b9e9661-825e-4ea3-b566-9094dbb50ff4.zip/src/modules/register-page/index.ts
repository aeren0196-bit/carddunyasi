export * from './register-page';
export { default } from './register-page';
