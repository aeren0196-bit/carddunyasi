import { Star, Quote } from "lucide-react";
import { useTranslation } from "react-i18next";
import { cn } from "@/lib/utils";
import { Card, CardContent } from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";

interface TestimonialsGridProps {
  className?: string;
}

export function TestimonialsGrid({ className }: TestimonialsGridProps) {
  const { t } = useTranslation("testimonials-grid");

  const testimonials = [
    {
      id: 1,
      name: t("testimonial1Name", "Alex Thompson"),
      role: t("testimonial1Role", "CEO at TechStart"),
      image: "/images/placeholder.png",
      review: t("testimonial1Review", "Incredible experience from start to finish. The team went above and beyond to ensure we got exactly what we needed. Would highly recommend."),
      rating: 5,
    },
    {
      id: 2,
      name: t("testimonial2Name", "Maria Garcia"),
      role: t("testimonial2Role", "Marketing Director"),
      image: "/images/placeholder.png",
      review: t("testimonial2Review", "The attention to detail is remarkable. Every aspect of the product shows careful thought and excellent execution. Our team loves it."),
      rating: 5,
    },
    {
      id: 3,
      name: t("testimonial3Name", "David Kim"),
      role: t("testimonial3Role", "Lead Developer"),
      image: "/images/placeholder.png",
      review: t("testimonial3Review", "As a developer, I appreciate clean code and good documentation. This delivers on both fronts. Integration was seamless and support was excellent."),
      rating: 5,
    },
  ];

  return (
    <section className={cn("py-16 md:py-24 bg-muted/30", className)}>
      <div className="w-full max-w-[var(--container-max-width)] mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold md:text-4xl mb-4">
            {t("title", "Trusted by Industry Leaders")}
          </h2>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            {t("subtitle", "See what professionals across various industries have to say about working with us.")}
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 max-w-6xl mx-auto">
          {testimonials.map((testimonial) => (
            <Card key={testimonial.id} className="relative overflow-hidden">
              <CardContent className="pt-6">
                {/* Quote Icon */}
                <Quote className="h-8 w-8 text-primary/20 mb-4" />

                {/* Review */}
                <p className="text-muted-foreground mb-6 leading-relaxed">
                  "{testimonial.review}"
                </p>

                {/* Rating */}
                <div className="flex items-center gap-1 mb-4">
                  {[...Array(5)].map((_, index) => (
                    <Star
                      key={index}
                      className={cn(
                        "h-4 w-4",
                        index < testimonial.rating
                          ? "fill-yellow-400 text-yellow-400"
                          : "fill-muted text-muted"
                      )}
                    />
                  ))}
                </div>

                {/* Author */}
                <div className="flex items-center gap-3 pt-4 border-t">
                  <Avatar className="h-10 w-10">
                    <AvatarImage
                      src={testimonial.image}
                      alt={testimonial.name}
                    />
                    <AvatarFallback>
                      {testimonial.name.charAt(0)}
                    </AvatarFallback>
                  </Avatar>
                  <div>
                    <p className="font-semibold text-sm">{testimonial.name}</p>
                    <p className="text-xs text-muted-foreground">
                      {testimonial.role}
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
}
