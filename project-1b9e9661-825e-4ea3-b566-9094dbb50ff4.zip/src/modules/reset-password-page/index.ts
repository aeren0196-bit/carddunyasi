export * from './reset-password-page';
export { default } from './reset-password-page';
