import { useState } from "react";
import { Link, useNavigate, useSearchParams } from "react-router";
import { toast } from "sonner";
import { Layout } from "@/components/Layout";
import { usePageTitle } from "@/hooks/use-page-title";
import { useTranslation } from "react-i18next";
import { useAuth } from "@/modules/auth-core";
import { getErrorMessage } from "@/modules/api";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
  CardDescription,
} from "@/components/ui/card";
import { KeyRound, ArrowLeft, Eye, EyeOff, CheckCircle2 } from "lucide-react";

export function ResetPasswordPage() {
  const { t } = useTranslation("reset-password-page");
  usePageTitle({ title: t("title", "Reset Password") });
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const { resetPassword } = useAuth();

  const code = searchParams.get("code") || "";
  const email = searchParams.get("email") || "";

  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [isSuccess, setIsSuccess] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    if (password !== confirmPassword) {
      setError(t("passwordMismatch", "Passwords do not match"));
      return;
    }

    if (!code || !email) {
      setError(
        t(
          "invalidLink",
          "Invalid or expired reset link. Please request a new one.",
        ),
      );
      return;
    }

    setIsLoading(true);

    try {
      await resetPassword(email, code, password);
      setIsSuccess(true);
      toast.success(
        t("passwordResetSuccess", "Password reset successfully!"),
      );
    } catch (err) {
      const errorMessage = getErrorMessage(
        err,
        t(
          "resetPasswordError",
          "Failed to reset password. Please try again.",
        ),
      );
      setError(errorMessage);
    } finally {
      setIsLoading(false);
    }
  };

  // Success state
  if (isSuccess) {
    return (
      <Layout>
        <div className="min-h-screen bg-muted/30 py-12">
          <div className="w-full max-w-[var(--container-max-width)] mx-auto px-4">
            <div className="max-w-md mx-auto">
              <Card>
                <CardContent className="pt-8 pb-8 text-center">
                  <CheckCircle2 className="w-16 h-16 text-green-500 mx-auto mb-4" />
                  <h1 className="text-2xl font-bold mb-2">
                    {t("passwordReset", "Password Reset!")}
                  </h1>
                  <p className="text-muted-foreground mb-6">
                    {t(
                      "passwordResetDescription",
                      "Your password has been reset successfully. You can now log in with your new password.",
                    )}
                  </p>
                  <Button asChild className="w-full">
                    <Link to="/login">
                      {t("goToLogin", "Go to Login")}
                    </Link>
                  </Button>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </Layout>
    );
  }

  // Invalid link state
  if (!code || !email) {
    return (
      <Layout>
        <div className="min-h-screen bg-muted/30 py-12">
          <div className="w-full max-w-[var(--container-max-width)] mx-auto px-4">
            <div className="max-w-md mx-auto">
              <Card>
                <CardContent className="pt-8 pb-8 text-center">
                  <h1 className="text-2xl font-bold mb-2 text-red-600">
                    {t("invalidLinkTitle", "Invalid Reset Link")}
                  </h1>
                  <p className="text-muted-foreground mb-6">
                    {t(
                      "invalidLinkDescription",
                      "This password reset link is invalid or has expired. Please request a new one.",
                    )}
                  </p>
                  <Button
                    onClick={() => navigate("/forgot-password")}
                    className="w-full mb-3"
                  >
                    {t("requestNewLink", "Request New Link")}
                  </Button>
                  <Link
                    to="/login"
                    className="inline-flex items-center justify-center gap-1 text-sm text-muted-foreground hover:text-primary"
                  >
                    <ArrowLeft className="w-4 h-4" />
                    {t("backToLogin", "Back to Login")}
                  </Link>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </Layout>
    );
  }

  return (
    <Layout>
      <div className="min-h-screen bg-muted/30 py-12">
        <div className="w-full max-w-[var(--container-max-width)] mx-auto px-4">
          <div className="text-center mb-12">
            <h1 className="text-4xl font-bold text-foreground mb-4">
              {t("title", "Reset Password")}
            </h1>
            <div className="w-16 h-1 bg-primary mx-auto mb-6"></div>
            <p className="text-lg text-muted-foreground max-w-xl mx-auto">
              {t("subtitle", "Enter your new password below")}
            </p>
          </div>

          <div className="max-w-md mx-auto">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <KeyRound className="w-5 h-5 text-primary" />
                  {t("resetPassword", "Reset Password")}
                </CardTitle>
                <CardDescription>
                  {t("subtitle", "Enter your new password below")}
                </CardDescription>
              </CardHeader>
              <CardContent>
                <form onSubmit={handleSubmit} className="space-y-6">
                  <div>
                    <Label htmlFor="password">
                      {t("newPassword", "New Password")} *
                    </Label>
                    <div className="relative">
                      <Input
                        id="password"
                        type={showPassword ? "text" : "password"}
                        value={password}
                        onChange={(e) => setPassword(e.target.value)}
                        placeholder={t(
                          "newPasswordPlaceholder",
                          "Enter new password",
                        )}
                        required
                        className="mt-1 pr-10"
                        autoComplete="new-password"
                        minLength={8}
                        disabled={isLoading}
                      />
                      <button
                        type="button"
                        onClick={() => setShowPassword(!showPassword)}
                        className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
                      >
                        {showPassword ? (
                          <EyeOff className="w-4 h-4" />
                        ) : (
                          <Eye className="w-4 h-4" />
                        )}
                      </button>
                    </div>
                    <p className="text-xs text-muted-foreground mt-1">
                      {t(
                        "passwordRequirements",
                        "At least 8 characters, 1 letter and 1 number",
                      )}
                    </p>
                  </div>

                  <div>
                    <Label htmlFor="confirmPassword">
                      {t("confirmPassword", "Confirm Password")} *
                    </Label>
                    <Input
                      id="confirmPassword"
                      type={showPassword ? "text" : "password"}
                      value={confirmPassword}
                      onChange={(e) => setConfirmPassword(e.target.value)}
                      placeholder={t(
                        "confirmPasswordPlaceholder",
                        "Confirm new password",
                      )}
                      required
                      className="mt-1"
                      autoComplete="new-password"
                      minLength={8}
                      disabled={isLoading}
                    />
                  </div>

                  {error && (
                    <div className="p-4 bg-red-50 border border-red-200 rounded-lg">
                      <p className="text-red-800 text-sm font-medium">
                        {error}
                      </p>
                    </div>
                  )}

                  <Button
                    type="submit"
                    size="lg"
                    className="w-full"
                    disabled={isLoading}
                  >
                    {isLoading ? (
                      <>
                        <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin mr-2" />
                        {t("resetting", "Resetting...")}
                      </>
                    ) : (
                      t("resetPassword", "Reset Password")
                    )}
                  </Button>

                  <div className="text-center">
                    <Link
                      to="/login"
                      className="text-sm text-muted-foreground hover:text-primary inline-flex items-center gap-1"
                    >
                      <ArrowLeft className="w-4 h-4" />
                      {t("backToLogin", "Back to Login")}
                    </Link>
                  </div>
                </form>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </Layout>
  );
}

export default ResetPasswordPage;
