import { useParams, useNavigate } from "react-router";
import { useDbGet } from "@/db";
import type { Product } from "@/modules/ecommerce-core/types";
import { ProductDetailBlock } from "@/modules/product-detail-block";
import { Layout } from "@/components/Layout";
import { usePageTitle } from "@/hooks/use-page-title";
import { useTranslation } from "react-i18next";
import { ArrowLeft } from "lucide-react";
import { Button } from "@/components/ui/button";

export function ProductDetailPage() {
  const { t } = useTranslation("product-detail-page");
  const { slug } = useParams<{ slug: string }>();
  const navigate = useNavigate();
  const { data: product, isLoading: loading, error } = useDbGet<Product>("products", {
    where: { slug: slug || "" },
    enabled: !!slug,
  });

  usePageTitle({ title: product?.name || t("loading", "Loading...") });

  if (loading) {
    return (
      <Layout>
        <div className="w-full max-w-[var(--container-max-width)] mx-auto px-4 py-8">
          <Button
            variant="ghost"
            onClick={() => navigate(-1)}
            className="mb-6 flex items-center gap-2 text-yellow-400 hover:text-yellow-300 hover:bg-yellow-400/10 font-semibold"
          >
            <ArrowLeft className="w-5 h-5" />
            {t("backButton", "Geri Dön")}
          </Button>
          <div className="animate-pulse">
            <div className="grid lg:grid-cols-2 gap-12">
              <div className="aspect-square bg-muted rounded-lg"></div>
              <div className="space-y-4">
                <div className="h-6 bg-muted rounded w-1/4"></div>
                <div className="h-10 bg-muted rounded w-3/4"></div>
                <div className="h-4 bg-muted rounded w-1/3"></div>
                <div className="h-8 bg-muted rounded w-1/4"></div>
                <div className="space-y-2">
                  <div className="h-4 bg-muted rounded"></div>
                  <div className="h-4 bg-muted rounded"></div>
                  <div className="h-4 bg-muted rounded w-2/3"></div>
                </div>
                <div className="h-12 bg-muted rounded w-1/2"></div>
              </div>
            </div>
          </div>
        </div>
      </Layout>
    );
  }

  if (error || !product) {
    return (
      <Layout>
        <div className="w-full max-w-[var(--container-max-width)] mx-auto px-4 py-8 text-center">
          <Button
            variant="ghost"
            onClick={() => navigate(-1)}
            className="mb-6 flex items-center gap-2 text-yellow-400 hover:text-yellow-300 hover:bg-yellow-400/10 font-semibold"
          >
            <ArrowLeft className="w-5 h-5" />
            {t("backButton", "Geri Dön")}
          </Button>
          <h1 className="text-2xl font-bold mb-4">{t("notFound", "Product Not Found")}</h1>
          <p className="text-muted-foreground">{t("notFoundDescription", "The product you're looking for doesn't exist or has been removed.")}</p>
        </div>
      </Layout>
    );
  }

  return (
    <Layout>
      <div className="w-full max-w-[var(--container-max-width)] mx-auto px-4 py-8">
        {/* Geri Dönme Butonu */}
        <Button
          variant="ghost"
          onClick={() => navigate(-1)}
          className="mb-6 flex items-center gap-2 text-yellow-400 hover:text-yellow-300 hover:bg-yellow-400/10 font-semibold"
        >
          <ArrowLeft className="w-5 h-5" />
          {t("backButton", "Geri Dön")}
        </Button>
        <ProductDetailBlock product={product} />
      </div>
    </Layout>
  );
}

export default ProductDetailPage;
