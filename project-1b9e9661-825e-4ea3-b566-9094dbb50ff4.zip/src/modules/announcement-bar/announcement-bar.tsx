import { useState } from "react";
import { Link } from "react-router";
import { useTranslation } from "react-i18next";
import { X, ArrowRight, Sparkles, Megaphone, Gift, Zap } from "lucide-react";
import { cn } from "@/lib/utils";
import { motion, AnimatePresence } from "motion/react";

type BarVariant = "default" | "primary" | "warning" | "success" | "gradient";

interface AnnouncementBarProps {
  message?: string;
  linkText?: string;
  linkUrl?: string;
  variant?: BarVariant;
  icon?: "sparkles" | "megaphone" | "gift" | "zap" | "none";
  dismissible?: boolean;
  storageKey?: string;
  className?: string;
}

const icons = {
  sparkles: Sparkles,
  megaphone: Megaphone,
  gift: Gift,
  zap: Zap,
  none: null,
};

const variantStyles: Record<BarVariant, string> = {
  default: "bg-muted text-muted-foreground",
  primary: "bg-primary text-primary-foreground",
  warning: "bg-yellow-500 text-yellow-950",
  success: "bg-green-500 text-white",
  gradient: "bg-gradient-to-r from-primary via-purple-500 to-pink-500 text-white",
};

export function AnnouncementBar({
  message,
  linkText,
  linkUrl = "#",
  variant = "primary",
  icon = "sparkles",
  dismissible = true,
  storageKey = "announcement-bar-dismissed",
  className,
}: AnnouncementBarProps) {
  const { t } = useTranslation("announcement-bar");
  const [isVisible, setIsVisible] = useState(() => {
    if (typeof window === "undefined") return false;
    if (dismissible) {
      return !localStorage.getItem(storageKey);
    }
    return true;
  });

  const displayMessage = message || t("message", "Exciting news! Check out our latest features.");
  const displayLinkText = linkText || t("linkText", "Learn more");

  const handleDismiss = () => {
    if (dismissible) {
      localStorage.setItem(storageKey, "true");
    }
    setIsVisible(false);
  };

  const IconComponent = icons[icon];

  return (
    <AnimatePresence>
      {isVisible && (
        <motion.div
          initial={{ height: 0, opacity: 0 }}
          animate={{ height: "auto", opacity: 1 }}
          exit={{ height: 0, opacity: 0 }}
          transition={{ duration: 0.3 }}
          className={cn(
            "relative overflow-hidden",
            variantStyles[variant],
            className
          )}
        >
          <div className="w-full max-w-[var(--container-max-width)] mx-auto px-4">
            <div className="flex items-center justify-center gap-2 py-2.5 text-sm font-medium">
              {IconComponent && (
                <IconComponent className="h-4 w-4 flex-shrink-0" />
              )}
              <span className="text-center">{displayMessage}</span>
              {linkUrl && (
                <Link
                  to={linkUrl}
                  className="inline-flex items-center gap-1 font-semibold hover:underline underline-offset-2"
                >
                  {displayLinkText}
                  <ArrowRight className="h-3 w-3" />
                </Link>
              )}
              {dismissible && (
                <button
                  onClick={handleDismiss}
                  className="absolute right-4 p-1 rounded hover:bg-black/10 transition-colors"
                  aria-label={t("dismiss", "Dismiss")}
                >
                  <X className="h-4 w-4" />
                </button>
              )}
            </div>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
