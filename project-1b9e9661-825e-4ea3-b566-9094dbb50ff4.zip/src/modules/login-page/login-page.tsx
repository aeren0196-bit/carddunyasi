import { useState } from "react";
import { Link, useNavigate, useLocation } from "react-router";
import { useTranslation } from "react-i18next";
import { toast } from "sonner";
import { usePageTitle } from "@/hooks/use-page-title";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Logo } from "@/components/Logo";
import { cn } from "@/lib/utils";
import { useAuth } from "@/modules/auth-core";
import { getErrorMessage } from "@/modules/api";
import { FormField } from "@/components/FormField";
import { PasswordInput } from "@/components/PasswordInput";

interface LoginPageProps {
  className?: string;
}

export function LoginPage({ className }: LoginPageProps) {
  const { t } = useTranslation("login-page");
  usePageTitle({ title: t("title", "Sign In") });
  const navigate = useNavigate();
  const location = useLocation();
  const { login } = useAuth();

  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const from = (location.state as { from?: string })?.from || "/";

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setIsLoading(true);

    try {
      await login(username, password);
      toast.success(t("loginSuccess", "Login successful!"));
      navigate(from, { replace: true });
    } catch (err) {
      const errorMessage = getErrorMessage(
        err,
        t("loginError", "Login failed. Please check your credentials.")
      );
      setError(errorMessage);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <section
      className={cn("flex min-h-screen bg-muted/30 px-4 py-16 md:py-32", className)}
    >
      <form
        onSubmit={handleSubmit}
        className="bg-muted m-auto h-fit w-full max-w-sm overflow-hidden rounded-xl border shadow-md"
      >
        <div className="bg-card -m-px rounded-xl border p-8 pb-6">
          <div className="text-center">
            <div className="mx-auto block w-fit">
              <Logo size="sm" />
            </div>
            <h1 className="mb-1 mt-4 text-xl font-semibold">
              {t("title", "Sign In")}
            </h1>
            <p className="text-sm text-muted-foreground">
              {t("subtitle", "Welcome back! Sign in to continue")}
            </p>
          </div>

          {error && (
            <div className="mt-4 p-3 text-sm text-red-600 bg-red-50 dark:bg-red-950 dark:text-red-400 rounded-md">
              {error}
            </div>
          )}

          <div className="mt-6 space-y-6">
            <FormField label={t("username", "Username")} htmlFor="username">
              <Input
                type="text"
                required
                name="username"
                id="username"
                autoComplete="username"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                placeholder={t("usernamePlaceholder", "Enter your username")}
                disabled={isLoading}
              />
            </FormField>
            <FormField
              label={t("password", "Password")}
              htmlFor="password"
              labelAction={
                <Button asChild variant="link" size="sm" className="h-auto p-0">
                  <Link to="/forgot-password" className="text-xs">
                    {t("forgotPassword", "Forgot password?")}
                  </Link>
                </Button>
              }
            >
              <PasswordInput
                id="password"
                name="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="••••••••"
                disabled={isLoading}
                required
              />
            </FormField>

            <Button type="submit" className="w-full" disabled={isLoading}>
              {isLoading ? (
                <>
                  <div className="w-4 h-4 border-2 border-primary-foreground border-t-transparent rounded-full animate-spin mr-2" />
                  {t("signingIn", "Signing in...")}
                </>
              ) : (
                t("signIn", "Sign In")
              )}
            </Button>
          </div>
        </div>

        <div className="p-3">
          <p className="text-center text-sm text-muted-foreground">
            {t("noAccount", "Don't have an account?")}
            <Button asChild variant="link" className="px-2">
              <Link to="/register">{t("createAccount", "Create account")}</Link>
            </Button>
          </p>
        </div>
      </form>
    </section>
  );
}

export default LoginPage;
