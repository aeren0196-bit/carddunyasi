"use client";

import { useTranslation } from "react-i18next";
import { cn } from "@/lib/utils";

interface Logo {
  name: string;
  image: string;
  url?: string;
}

interface LogoCloudProps {
  logos?: Logo[];
  title?: string;
  grayscale?: boolean;
  animate?: boolean;
  speed?: "slow" | "normal" | "fast";
  pauseOnHover?: boolean;
  className?: string;
}

const defaultLogos: Logo[] = [
  { name: "Company 1", image: "/images/placeholder.png" },
  { name: "Company 2", image: "/images/placeholder.png" },
  { name: "Company 3", image: "/images/placeholder.png" },
  { name: "Company 4", image: "/images/placeholder.png" },
  { name: "Company 5", image: "/images/placeholder.png" },
  { name: "Company 6", image: "/images/placeholder.png" },
];

const speedDuration = {
  slow: "40s",
  normal: "25s",
  fast: "15s",
};

export function LogoCloud({
  logos = defaultLogos,
  title,
  grayscale = true,
  animate = true,
  speed = "slow",
  pauseOnHover = true,
  className,
}: LogoCloudProps) {
  const { t } = useTranslation("logo-cloud");

  const displayTitle = title ?? t("title");

  const renderLogo = (logo: Logo, index: number) => {
    const imageElement = (
      <img
        src={logo.image}
        alt={logo.name}
        className={cn(
          "h-10 md:h-12 w-auto object-contain transition-all duration-300 rounded-[var(--radius)]",
          grayscale && "grayscale opacity-60 hover:grayscale-0 hover:opacity-100"
        )}
        draggable={false}
      />
    );

    if (logo.url) {
      return (
        <a
          key={index}
          href={logo.url}
          target="_blank"
          rel="noopener noreferrer"
          className="flex items-center justify-center px-8 md:px-12 shrink-0"
        >
          {imageElement}
        </a>
      );
    }

    return (
      <div key={index} className="flex items-center justify-center px-8 md:px-12 shrink-0">
        {imageElement}
      </div>
    );
  };

  return (
    <section className={cn("py-12 md:py-16 overflow-hidden", className)}>
      <div className="container max-w-[var(--container-max-width)] mx-auto px-4">
        {displayTitle && (
          <p className="text-center text-sm font-medium text-muted-foreground uppercase tracking-wider mb-8">
            {displayTitle}
          </p>
        )}
      </div>

      {/* Marquee Container */}
      <div
        className={cn(
          "relative w-full",
          pauseOnHover && "[&:hover_.marquee-content]:pause"
        )}
      >
        {/* Gradient Masks */}
        <div className="absolute left-0 top-0 bottom-0 w-20 md:w-32 bg-gradient-to-r from-background to-transparent z-10 pointer-events-none" />
        <div className="absolute right-0 top-0 bottom-0 w-20 md:w-32 bg-gradient-to-l from-background to-transparent z-10 pointer-events-none" />

        {/* Scrolling Content */}
        <div className="flex overflow-hidden">
          <div
            className={cn(
              "marquee-content flex items-center",
              animate && "animate-marquee"
            )}
            style={{
              ["--marquee-duration" as string]: speedDuration[speed],
            }}
          >
            {/* First set of logos */}
            {logos.map((logo, index) => renderLogo(logo, index))}
            {/* Duplicate for seamless loop */}
            {logos.map((logo, index) => renderLogo(logo, index + logos.length))}
          </div>
        </div>
      </div>

      <style>{`
        @keyframes marquee {
          0% {
            transform: translateX(0);
          }
          100% {
            transform: translateX(-50%);
          }
        }
        .animate-marquee {
          animation: marquee var(--marquee-duration, 25s) linear infinite;
        }
        .pause {
          animation-play-state: paused !important;
        }
      `}</style>
    </section>
  );
}
