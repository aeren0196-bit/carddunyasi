# Order Confirmation Page

Post-checkout order confirmation page. Displays order summary, payment status for Stripe payments, and order details. Reads pending checkout from localStorage and clears cart on success.

## Exports

**Components:** OrderConfirmationPage, default

## Usage

```tsx
import OrderConfirmationPage from '@/modules/order-confirmation-page';

<OrderConfirmationPage />

• Installed at: src/modules/order-confirmation-page/
• Customize text: src/modules/order-confirmation-page/lang/*.json
• Reads 'pending_checkout' from localStorage
• Checks payment status for Stripe payments
• Add to your router as a page component
```

## Dependencies

- button
- api
- ecommerce-core

