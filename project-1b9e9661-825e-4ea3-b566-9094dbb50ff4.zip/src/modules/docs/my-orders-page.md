# My Orders Page

User orders listing page with order cards showing status, date, total, and items. Requires authentication and fetches orders from API. Features loading skeleton and empty state.

## Exports

**Components:** MyOrdersPage, default

## Usage

```tsx
import MyOrdersPage from '@/modules/my-orders-page';

<MyOrdersPage />

• Installed at: src/modules/my-orders-page/
• Customize text: src/modules/my-orders-page/lang/*.json
• Uses customerClient.orders.getMyOrders() for API
• Requires user to be authenticated
• Add to your router as a page component
```

## Dependencies

- button
- badge
- skeleton
- auth-core
- api
- ecommerce-core

