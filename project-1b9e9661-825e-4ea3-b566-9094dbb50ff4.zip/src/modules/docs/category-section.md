# Category Section

E-commerce category showcase grid with image cards. Each card has category image, name overlay, and hover zoom effect. Supports 4-6 categories in responsive grid (2 cols mobile, 3 cols tablet, 4+ cols desktop). Click navigates to filtered products page. Great for homepage category browsing.

## Exports

**Components:** CategorySection

**Types:** CategoryItem, CategorySectionProps

## Usage

```tsx
import { CategorySection } from '@/modules/category-section';

<CategorySection />

• Installed at: src/modules/category-section/
• Customize content: src/modules/category-section/lang/*.json
• Categories link to: /products?category={slug}
```

