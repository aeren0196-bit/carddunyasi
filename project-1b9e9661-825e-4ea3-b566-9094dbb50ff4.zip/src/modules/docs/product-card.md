# Product Card

Versatile e-commerce product card with 4 variants: 'grid' (standard), 'list' (horizontal), 'featured' (large with badge), 'compact' (minimal). Includes add-to-cart button and favorite toggle. Shows price, sale badge, and rating.

## Exports

**Components:** ProductCard

## Usage

```tsx
import { ProductCard } from '@/modules/product-card';

<ProductCard product={product} variant="grid" />

• Props: product (Product from ecommerce-core), variant (grid|list|featured|compact)
• Uses useCart() and useFavorites() from ecommerce-core (Zustand)
• Features: add to cart, toggle favorite, sale badge, rating display
```

## Dependencies

- ecommerce-core

