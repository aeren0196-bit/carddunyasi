# Cart Drawer

Shopping cart drawer that slides in from the right. Integrated with ecommerce-core store. Displays cart items with images, prices, quantity controls, remove buttons, subtotal calculation, and checkout button.

## Exports

**Components:** CartDrawer

## Usage

```tsx
import { CartDrawer } from '@/modules/cart-drawer';

// Cart state is managed by ecommerce-core store
<CartDrawer checkoutHref="/checkout" />

// The drawer opens automatically when items are added to cart
// Or use useCart hook to control it:
import { useCart } from '@/modules/ecommerce-core';
const { setDrawerOpen } = useCart();
setDrawerOpen(true);
```

## Dependencies

- sheet
- button
- ecommerce-core

