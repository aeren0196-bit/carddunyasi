# Checkout Page

Full-featured checkout page with customer information form, payment method selection (card, bank transfer, cash on delivery), and online payment provider selection (Stripe, iyzico). Integrates with payment API for creating checkout sessions and fetching bank transfer info. Features form validation, order summary sidebar, and skeleton loading states.

## Exports

**Components:** CheckoutPage, default

## Usage

```tsx
import CheckoutPage from '@/modules/checkout-page';

<Route path="/checkout" element={<CheckoutPage />} />

• Uses useCart() from ecommerce-core (Zustand)
• Steps: customer info → shipping → payment → review
• Form validation with react-hook-form
• Connect payment provider (Stripe, PayPal, etc.)
```

## Dependencies

- ecommerce-core
- animations
- api

